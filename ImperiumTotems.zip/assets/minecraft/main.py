from PIL import Image
import sys, copy, json

img_arr = copy.deepcopy(sys.argv)
img_arr.pop(0)

img = Image.open(img_arr[0])

szx, szy = img.size

oimg = Image.new("RGBA", (szx, szy*len(img_arr)))

for i in range(len(img_arr)):
    cimg = Image.open(img_arr[i])
    oimg.paste(cimg, (0,szy*i))

oimg.save("out.png")

d = {
    "animation":
    {
        "frametime":len(img_arr),
        "frames": [
            {"index":0, "time": 100},
            1,
            {"index":2, "time": 3},
            {"index":3, "time": 3}
        ]
    }
}

f = open("out.png.mcmeta", "w")
f.write(json.dumps(d, ensure_ascii=False))
f.close()